import Game from './js/game.js';

window.addEventListener('DOMContentLoaded', () => {
	const game = new Game();
});